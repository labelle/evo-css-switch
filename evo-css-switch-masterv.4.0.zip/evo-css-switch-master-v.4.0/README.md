# evo-css-switch
A theme switcher. Swaps out css stye sheets.
if you want to add more styles to switch append 

<link rel="stylesheet" type="text/css" href="<styleheet path>" title="style1" class="new" media="screen" />

to css styles list.



